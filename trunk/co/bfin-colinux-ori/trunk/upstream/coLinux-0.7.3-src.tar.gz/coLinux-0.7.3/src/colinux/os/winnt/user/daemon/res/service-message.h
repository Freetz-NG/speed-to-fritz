// ***** service-messages.mc *****

// MessageId: MSG_SERVICE_INFO
// MessageText:
//  %1
//
#define MSG_SERVICE_INFO                 0x40000001L

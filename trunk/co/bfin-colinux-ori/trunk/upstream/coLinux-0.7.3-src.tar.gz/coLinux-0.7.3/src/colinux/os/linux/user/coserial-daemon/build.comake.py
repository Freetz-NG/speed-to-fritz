targets['build.o'] = Target(
    inputs=[
	Input('main.o'),
    ],
)

/* Placefolder file for QEMU's config.h */

targets['build.a'] = Target(
    inputs=[
       Input('head.o'),
    ],
)

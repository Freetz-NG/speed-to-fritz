#ifndef __COLINUX_WINNT_OS_H__
#define __COLINUX_WINNT_OS_H__

#define COLINUX_DRIVER_FILE "linux.sys"

#endif

#ifndef __COLINUX_OS_LINUX_MEMORY_H__
#define __COLINUX_OS_LINUX_MEMORY_H__

#ifdef __KERNEL__
# include "colinux/os/linux/kernel/module/linux_inc.h"
#else
# include <memory.h>
#endif

#endif

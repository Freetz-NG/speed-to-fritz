targets['build.o'] = Target(
    inputs=[
       Input('head.o'),
    ],
)

targets['user.a'] = Target(
    inputs=input_list(".c", ".o"),
)

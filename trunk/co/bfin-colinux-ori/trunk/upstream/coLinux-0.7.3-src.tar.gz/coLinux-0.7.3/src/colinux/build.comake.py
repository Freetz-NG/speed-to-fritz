targets['user.a'] = Target(
    inputs=[
    Input("user/user.a"),
    Input("common/common.a"),    
    ]
)

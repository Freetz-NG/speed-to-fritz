#include "console.h"

const char *console_window_NT_t::get_name()
{
	return "colinux-console-nt.exe";
}


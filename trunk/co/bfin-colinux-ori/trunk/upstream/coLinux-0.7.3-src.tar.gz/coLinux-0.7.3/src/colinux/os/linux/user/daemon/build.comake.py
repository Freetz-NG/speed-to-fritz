targets['daemon.o'] = Target(
    inputs = input_list(".c", ".o"),
)

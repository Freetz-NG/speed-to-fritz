targets['build.a'] = Target(
    inputs=input_list('.cpp', '.o'),
)

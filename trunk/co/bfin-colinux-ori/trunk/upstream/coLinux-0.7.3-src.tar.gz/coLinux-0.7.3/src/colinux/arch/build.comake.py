targets['build.o'] = Target(
    inputs=[
    Input("current/build.o"),
    ]
)

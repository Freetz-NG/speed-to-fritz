#ifndef __COLINUX_OS_WINNT_MEMORY_H__
#define __COLINUX_OS_WINNT_MEMORY_H__

#include <memory.h>

#endif

#include "debug.h"

void co_daemon_trace_point(co_trace_point_info_t *info)
{
}

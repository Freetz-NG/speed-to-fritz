Just in case you might want to keep on using ESD instead of PulseAudio:
- unzip these files into subdirectory Sound
- edit settings.txt: change the line
  exec0="pulseaudio\pulseaudio.exe"
  back into
  exec0="Sound\esd.exe","-tcp -public"
  (depending on your config this line may start with exec1 instead of exec0)
- allow esd.exe to open ports in your firewall
